import React, { Component } from 'react';
import Navbar from './Components/Navbar';
import {BrowserRouter} from 'react-router-dom';
import Route from 'react-router-dom/Route';
import Product from './Components/Product';
import RegisterForm from './Components/RegisterForm';
import LoginForm from './Components/LoginForm';
import './App.css';





class App extends Component {   
    render() {
        return (
          <BrowserRouter>
            <div className="container-fluid"> 
                <Navbar/>   
                
                <Route exact path="/" component={Product} />  
                <Route exact path="/register" component={RegisterForm} />
                <Route exact path="/login" component={LoginForm} /> 
                <Route exact path="/products" component={Product} />  
            </div>
        </BrowserRouter>
            
        );
    }
}

export default App;