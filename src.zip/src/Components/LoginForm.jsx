import React, { Component } from 'react';
import Button from './Common/Button';
import Joi from 'joi-browser';
import Form from './Common/Form';

class LoginForm extends Form {

    state = {
        data : { username : '', password : ''},
        errors : { }
    }

    schema = {
        username : Joi.string().min(3).required().label('Username'),
        password : Joi.string().required().label('Password')
    }

    doSumbmit = ()=>{
        //communicate to server...
        console.log('Submitted....')
        console.log(this.state.data)
    }

    render() {
        const {data, errors} = this.state;
        return (
            <div>
                
                <form onSubmit={this.handleSubmit}>                    
                   {this.renderInput('username', data.username, "Username", "Enter Username", errors.username)}
                   {this.renderInput('password', data.password, "Password", "Enter Password", errors.password, "password")}        
                    <Button label='Submit' />
                </form>
            </div>
        );
    }
}
                
export default LoginForm;