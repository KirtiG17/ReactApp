import React from 'react';

const Input = ({name, value, type, label, placeholder, onChange,error}) => {
    return (
        <div className="form-group row">
            <div class="col-md-4 offset-md-4">
            <label htmlFor={name}>{label}</label>
            <input 
                type={type} 
                className="form-control" 
                id={name}  
                value={value}
                onChange={onChange}
                name={name}
                placeholder={placeholder} />
            {error && <div className="alert alert-danger">{error}</div>}
            </div>
        </div>
    );
};

export default Input;