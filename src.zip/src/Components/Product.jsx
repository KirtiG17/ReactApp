import React, { Component } from 'react';
import {Button, Modal, ModalHeader, ModalFooter, ModalBody, Label, Input, FormGroup} from 'reactstrap';
import axios from 'axios';

const apiEndPoint = "https://jsonplaceholder.typicode.com/posts";

class Product extends Component {
    state = {
        comments:[],
        newCommentData:{
          title:'',
          body:''
        },
        editCommentData:{
          id:'',
          title:'',
          body:''
        },
        newComment : false,
        editCommentToggle : false
      }
  
      componentDidMount = () => {
          axios.get(apiEndPoint)
          .then(response => {
              const comments = response.data;
              this.setState({comments});
          })
      }
      componentWillMount(){
        this._refreshComment();
      }
  
      addComment=()=>{
        axios.post(apiEndPoint,this.state.newCommentData).then(response=>{
          let { comments } = this.state;
          comments.push(response.data);
          this.setState({
            comments,
            newComment:false
          })
        })
      }
      editComment=comment=>{
        const id = comment.id;
        const title = comment.title;
        const body = comment.body;
        this.setState({
          editCommentData:{id,title,body},
          editCommentToggle : !this.state.editCommentToggle
        })
  
      }
      updateComment(){
        
        let {title,body}=this.state.editCommentData;
        alert("Product Name : "+ title +"Product Description :"+ body )
        axios.put(apiEndPoint + '/' + this.state.editCommentData.id,{title,body}).then(response=>{
          this._refreshComment()
        })
        this.setState({        
          editCommentToggle : !this.state.editCommentToggle
        })
      }
  
  
      handleDelete = async comment => {
        const originalComments = [...this.state.comments]  
        const comments = this.state.comments.filter(p=>p.id !== comment.id)
        this.setState({comments})      
        try{
           await axios.delete(apiEndPoint + '/' + comment.id)
        }catch(ex){  
            if(ex.response && ex.response.status === 404)
              alert('This post has already deleted...')          
            this.setState({posts:originalComments})
        }
     
      };
      
      _refreshComment(){
        axios.get(apiEndPoint)
          .then(response => {
              const comments = response.data;
              this.setState({comments});
          })
      }
      toggleNewCommentModal = () => {
        this.setState({
          newComment: !this.state.newComment})
      }
      toggleEditCommentModal = () => {
        this.setState({
          editCommentToggle: !this.state.editCommentToggle})
      }
  
      render() {
          let comments = this.state.comments.map(comment =>                     
            <tr key={comment.id}>
                <td>{comment.id}</td>
                <td>{comment.title}</td>
                <td>{comment.body}</td>
                <td>
                <button type="button" className="btn btn-primary btn-sm m-1 buttonWidth" onClick={() => this.editComment(comment)}>Update</button>
                <button type="button" className="btn btn-danger btn-sm m-1 buttonWidth" onClick={() => this.handleDelete(comment)}>Delete</button>
                </td>
            </tr>
        )
          return (
              <div>
                  {/* Add */}
                  <Button color="success m-1" onClick={this.toggleNewCommentModal}>Add new product</Button>
                  <Modal isOpen={this.state.newComment} fade={false} toggle={this.toggleNewCommentModal}>
                    <ModalHeader toggle={this.toggleNewCommentModal}>Add a new comment</ModalHeader>
                    <ModalBody>
                      <FormGroup>        
                        <Label for="name">Product Name</Label>
                        <Input type="text" value={this.state.newCommentData.title} onChange={(e)=>{
                          let {newCommentData} = this.state;
                          newCommentData.title = e.target.value;
                          this.setState({newCommentData})
                        }}/>
                        <Label for="body">Product Description</Label>
                        <Input type="text" value={this.state.newCommentData.body} onChange={(e)=>{
                          let {newCommentData} = this.state;
                          newCommentData.body = e.target.value;
                          this.setState({newCommentData})
                        }}/>
                      </FormGroup>
                    </ModalBody>
                    <ModalFooter>
                    <Button color="primary" onClick={this.addComment}>Add</Button>{' '}
                    <Button color="secondary" onClick={this.toggleNewCommentModal}>Cancel</Button>
                   </ModalFooter>
                  </Modal>
  
                  {/* Update  */}
                  <Modal isOpen={this.state.editCommentToggle} fade={false} toggle={this.toggleEditCommentModal.bind(this)}>
                    <ModalHeader toggle={this.toggleEditCommentModal}>Update Product detail</ModalHeader>
                    <ModalBody>
                      <FormGroup>     
                      <Label for="id">Product Id</Label>
                        <Input type="text" value={this.state.editCommentData.id} onChange={(e)=>{
                          let {editCommentData} = this.state;
                          editCommentData.id = e.target.value;
                          this.setState({editCommentData})
                        }}/>
                        <Label for="name">Product Name</Label>
                        <Input type="text" value={this.state.editCommentData.title} onChange={(e)=>{
                          let {editCommentData} = this.state;
                          editCommentData.title = e.target.value;
                          this.setState({editCommentData})
                        }}/>
                        <Label for="body">Product Description</Label>
                        <Input type="text" value={this.state.editCommentData.body} onChange={(e)=>{
                          let {editCommentData} = this.state;
                          editCommentData.body = e.target.value;
                          this.setState({editCommentData})
                        }}/>
                      </FormGroup>
                    </ModalBody>
                    <ModalFooter>
                    <Button color="primary" onClick={this.updateComment.bind(this)}>Update</Button>{' '}
                    <Button color="secondary" onClick={this.toggleEditCommentModal.bind(this)}>Cancel</Button>
                   </ModalFooter>
                  </Modal>
  
                  <table className="table">
                      <thead className="thead-light">
                          <tr>
                              <th>Product Id</th>
                              <th>Product Name</th>
                              <th>Product Description</th>
                              <th>Action</th>
                          </tr>
                      </thead>
                      <tbody>
                      {comments}
                      </tbody>
                  </table>
                  
              </div>
          );
      }
  }

export default Product;